module.exports = {
    logger: function logger(msg) {
        console.log(msg);
    },
}

